# League of Legends Hub

Full stack project that allows users to post comments/guides, look up the leaderboard, read up on a champion guide, and search up the profile of a player.  