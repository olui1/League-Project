import React from 'react'

const Header = () => {
    return (
        <div>
           <h1 className="mt-5 display-5 text-center" style={{color:"white"}}>Post/Guides</h1> 
        </div>
    )
}

export default Header
