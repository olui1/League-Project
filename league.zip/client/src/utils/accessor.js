export default function first(arr){
    if (arr.length <= 0) {
        return null;
    }
    return arr[0];
}

