import React from 'react';
import UpdatePosts from '../components/UpdatePosts';

const UpdatePostPage = () => {
    return (
        <div>
            <UpdatePosts/>
        </div>
    )
}

export default UpdatePostPage
