export default class CurrentPlayer{    
    constructor(){
        this.playerId = "";
        this.championId = "";
        this.spell1 = "";
        this.spell2 = "";
        this.rune1 = "";
        this.rune2 = "";
        this.kills = "";
        this.deaths = "";
        this.assists = "";
        this.cs = "";
        this.wins = "";
    }
}